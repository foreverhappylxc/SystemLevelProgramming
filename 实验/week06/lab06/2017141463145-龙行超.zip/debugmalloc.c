#include <stdlib.h>
#include <string.h>
#include "debugmalloc.h"
#include "dmhelper.h"
#include <stdio.h>

int bitCount(int x) {

    /* Sum 8 groups of 4 bits each */
    int m1 = 0x11 | (0x11 << 8);
    int mask = m1 | (m1 << 16);
    int s = x & mask;
    s += x>>1 & mask;
    s += x>>2 & mask;
    s += x>>3 & mask;
    /* Now combine high and low order sums */
    s = s + (s >> 16);
    //printf("s=%x\n",s);

    /* Low order 16 bits now consists of 4 sums,
    each ranging between 0 and 8.
    Split into two groups and sum */
    mask = 0xF | (0xF << 8);
    s = (s & mask) + ((s >> 4) & mask);
    return (s + (s>>8)) & 0x3F;
}

typedef struct record{
    int checkSum;
    char * fileName;
    int lineNumber;
    size_t size;
    int fence;
    void *payload;
    struct record * next;
} record;

record * head;
record * tail;
record * curr;
int length = 0;

void initialHead() {
    if (length == 0) {
        head = (record *) malloc(sizeof(record *));
        head->checkSum = 0;
        head->fileName = NULL;
        head->lineNumber = 0;
        head->size = 0;
        head->fence = 0;
        head->payload = NULL;
        head->next = NULL;
        tail = head;
    }
}

void append(int checkSum, char * fileName, int lineNumber, size_t size, void *payload) {
    record * newNode = (record *) malloc(sizeof(record));
    initialHead();
    newNode->checkSum = checkSum;
    newNode->fileName = fileName;
    newNode->lineNumber = lineNumber;
    newNode->size = size;
    newNode->fence = 0xCCDEADCC;
    newNode->payload = payload;
    newNode->next = NULL;
    tail->next = newNode;
    tail = newNode;
    length++;
}

int find(void *payload) {
    initialHead();
    curr = head;
    while (curr->next != NULL) {
        if (curr->next->payload == payload) {
            return 1;
        }
        curr = curr->next;
    }
    return 0;
}

void removeNode(void *payload) {
    find(payload);
    record * tmp = curr->next;
    curr->next = curr->next->next;
    free(tmp);
    length--;
}

int headerCorrect(record * r) {
    int * tmp = (int *) r->payload;
    if (r->checkSum != *(tmp - 2)) {
        return 0;
    }
    return 1;
}

int headerFenceCorrect(record * r) {
    int * tmp = (int *) r->payload;
    if (r->fence != *(tmp - 1)) {
        return 0;
    }
    return 1;
}

int footerFenceCorrect(record * r) {
    int * tmp = (int *) r->payload;
        if (r->fence != *(tmp + r->size / 4)) {
            return 0;
        }
        return 1;
}


/* Wrappers for malloc and free */

void *MyMalloc(size_t size, char *filename, int linenumber) {
    int * newptr = NULL;
    int checkSum = bitCount(0xCCDEADCC);
    char * initial = NULL;
    newptr = (int *) malloc(size + 3 * sizeof(int));
    if (newptr == NULL) {
        printf("failed");
    }
    *newptr = checkSum;
    newptr = newptr + 1;
    *newptr = 0xCCDEADCC;
    newptr = newptr + 1;
    initial = (char *) newptr;
    initial = initial + size;
    newptr = (int *) initial;
    *newptr = 0xCCDEADCC;
    initial = initial - size;
    append(checkSum, filename, linenumber, size, initial);
    return initial;
}

void MyFree(void *ptr, char *filename, int linenumber) {
    int b = find(ptr);
    if (!b) {
        error(4, filename, linenumber);
    } else if (!headerCorrect(curr->next)) {
        errorfl(3, curr->next->fileName, curr->next->lineNumber, filename, linenumber);
    } else if (!headerFenceCorrect(curr->next)) {
        errorfl(1, curr->next->fileName, curr->next->lineNumber, filename, linenumber);
    } else if (!footerFenceCorrect(curr->next)) {
        errorfl(2, curr->next->fileName, curr->next->lineNumber, filename, linenumber);
    }
    removeNode(ptr);
	free((void *) ((int *) ptr - 2));
}

/* returns number of bytes allocated using MyMalloc/MyFree:
	used as a debugging tool to test for memory leaks */
int AllocatedSize() {
    if (length == 0) {
        return 0;
    }
    curr = head;
    int size = 0;
    while (curr->next != NULL) {
        size += curr->next->size;
        curr = curr->next;
    }
	return size;
}



/* Optional functions */

/* Prints a list of all allocated blocks with the
	filename/line number when they were MALLOC'd */
void PrintAllocatedBlocks() {
    if (length == 0) {
        return;
    }
    curr = head;
    printf("Currently allocated block: \n");
    while (curr->next != NULL) {
        PRINTBLOCK(curr->next->size, curr->next->fileName, curr->next->lineNumber);
        curr = curr->next;
    }
	return;
}

/* Goes through the currently allocated blocks and checks
	to see if they are all valid.
	Returns -1 if it receives an error, 0 if all blocks are
	okay.
*/
int HeapCheck() {
    if (length == 0) {
        return 0;
    }
    curr = head;
    while (curr->next != NULL) {
        if (!headerCorrect(curr->next)) {
            PRINTERROR(3, curr->next->fileName, curr->next->lineNumber);
            return -1;
        } else if (!headerFenceCorrect(curr->next)) {
            PRINTERROR(1, curr->next->fileName, curr->next->lineNumber);
            return -1;
        } else if (!footerFenceCorrect(curr->next)) {
            PRINTERROR(2, curr->next->fileName, curr->next->lineNumber);
            return -1;
        }
        curr = curr->next;
    }
	return 0;
}
