// precise.h -- access to precision timer

void precise_start();
double precise_stop();
